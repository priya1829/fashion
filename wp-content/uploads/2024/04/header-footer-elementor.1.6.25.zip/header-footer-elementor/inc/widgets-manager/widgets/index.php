<?php
/**
 * Silence is golden.
 *
 * @package header-footer-elementor
 */
